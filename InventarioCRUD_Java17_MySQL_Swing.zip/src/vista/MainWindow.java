package vista;

import dao.ClienteDAO;
import dao.ProductoDAO;
import modelo.Cliente;
import modelo.Producto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class MainWindow extends JFrame {

    private ProductoDAO productoDAO = new ProductoDAO();
    private ClienteDAO clienteDAO = new ClienteDAO();

    private DefaultTableModel productoModel;
    private DefaultTableModel clienteModel;
    private JTable productoTable;
    private JTable clienteTable;

    public MainWindow() {
        setTitle("Sistema de Inventario - Demo (Swing)");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();
        tabs.add("Productos", createProductoPanel());
        tabs.add("Clientes", createClientePanel());

        add(tabs);
        loadProductos();
        loadClientes();
    }

    private JPanel createProductoPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        productoModel = new DefaultTableModel(new String[] { "ID", "Nombre", "Descripcion", "Precio", "Stock" }, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        productoTable = new JTable(productoModel);
        JScrollPane scroll = new JScrollPane(productoTable);

        JPanel botones = new JPanel();
        JButton btnAdd = new JButton("Crear");
        JButton btnEdit = new JButton("Editar");
        JButton btnDel = new JButton("Eliminar");
        botones.add(btnAdd);
        botones.add(btnEdit);
        botones.add(btnDel);

        btnAdd.addActionListener(e -> abrirDialogoProducto(null));
        btnEdit.addActionListener(e -> {
            int sel = productoTable.getSelectedRow();
            if (sel >= 0) {
                int id = (int) productoModel.getValueAt(sel, 0);
                Producto p = productoDAO.obtenerPorId(id);
                abrirDialogoProducto(p);
            } else showInfo("Seleccione un producto para editar.");
        });
        btnDel.addActionListener(e -> {
            int sel = productoTable.getSelectedRow();
            if (sel >= 0) {
                int id = (int) productoModel.getValueAt(sel, 0);
                int conf = JOptionPane.showConfirmDialog(this, "¿Eliminar producto ID " + id + "?", "Confirmar", JOptionPane.YES_NO_OPTION);
                if (conf == JOptionPane.YES_OPTION) {
                    if (productoDAO.eliminar(id)) {
                        showInfo("Producto eliminado.");
                        loadProductos();
                    } else showError("Error al eliminar.");
                }
            } else showInfo("Seleccione un producto para eliminar.");
        });

        panel.add(scroll, BorderLayout.CENTER);
        panel.add(botones, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel createClientePanel() {
        JPanel panel = new JPanel(new BorderLayout());

        clienteModel = new DefaultTableModel(new String[] { "ID", "Nombre", "Correo", "Telefono", "Direccion" }, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        clienteTable = new JTable(clienteModel);
        JScrollPane scroll = new JScrollPane(clienteTable);

        JPanel botones = new JPanel();
        JButton btnAdd = new JButton("Crear");
        JButton btnEdit = new JButton("Editar");
        JButton btnDel = new JButton("Eliminar");
        botones.add(btnAdd);
        botones.add(btnEdit);
        botones.add(btnDel);

        btnAdd.addActionListener(e -> abrirDialogoCliente(null));
        btnEdit.addActionListener(e -> {
            int sel = clienteTable.getSelectedRow();
            if (sel >= 0) {
                int id = (int) clienteModel.getValueAt(sel, 0);
                Cliente c = clienteDAO.obtenerPorId(id);
                abrirDialogoCliente(c);
            } else showInfo("Seleccione un cliente para editar.");
        });
        btnDel.addActionListener(e -> {
            int sel = clienteTable.getSelectedRow();
            if (sel >= 0) {
                int id = (int) clienteModel.getValueAt(sel, 0);
                int conf = JOptionPane.showConfirmDialog(this, "¿Eliminar cliente ID " + id + "?", "Confirmar", JOptionPane.YES_NO_OPTION);
                if (conf == JOptionPane.YES_OPTION) {
                    if (clienteDAO.eliminar(id)) {
                        showInfo("Cliente eliminado.");
                        loadClientes();
                    } else showError("Error al eliminar.");
                }
            } else showInfo("Seleccione un cliente para eliminar.");
        });

        panel.add(scroll, BorderLayout.CENTER);
        panel.add(botones, BorderLayout.SOUTH);
        return panel;
    }

    private void abrirDialogoProducto(Producto p) {
        JTextField nombre = new JTextField();
        JTextField desc = new JTextField();
        JTextField precio = new JTextField();
        JTextField stock = new JTextField();

        if (p != null) {
            nombre.setText(p.getNombre());
            desc.setText(p.getDescripcion());
            precio.setText(String.valueOf(p.getPrecio()));
            stock.setText(String.valueOf(p.getStock()));
        }

        Object[] fields = {
                "Nombre:", nombre,
                "Descripcion:", desc,
                "Precio:", precio,
                "Stock:", stock
        };

        int option = JOptionPane.showConfirmDialog(this, fields, p == null ? "Crear Producto" : "Editar Producto", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                String n = nombre.getText().trim();
                String d = desc.getText().trim();
                double pr = Double.parseDouble(precio.getText().trim());
                int st = Integer.parseInt(stock.getText().trim());

                if (n.isEmpty()) { showError("El nombre es requerido."); return; }

                if (p == null) {
                    Producto np = new Producto(n, d, pr, st);
                    if (productoDAO.insertar(np)) {
                        showInfo("Producto creado. ID: " + np.getId());
                        loadProductos();
                    } else showError("Error al crear producto.");
                } else {
                    p.setNombre(n); p.setDescripcion(d); p.setPrecio(pr); p.setStock(st);
                    if (productoDAO.actualizar(p)) {
                        showInfo("Producto actualizado.");
                        loadProductos();
                    } else showError("Error al actualizar producto.");
                }
            } catch (NumberFormatException ex) {
                showError("Precio o stock no son válidos: " + ex.getMessage());
            }
        }
    }

    private void abrirDialogoCliente(Cliente c) {
        JTextField nombre = new JTextField();
        JTextField correo = new JTextField();
        JTextField telefono = new JTextField();
        JTextField direccion = new JTextField();

        if (c != null) {
            nombre.setText(c.getNombre());
            correo.setText(c.getCorreo());
            telefono.setText(c.getTelefono());
            direccion.setText(c.getDireccion());
        }

        Object[] fields = {
                "Nombre:", nombre,
                "Correo:", correo,
                "Telefono:", telefono,
                "Direccion:", direccion
        };

        int option = JOptionPane.showConfirmDialog(this, fields, c == null ? "Crear Cliente" : "Editar Cliente", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String n = nombre.getText().trim();
            String co = correo.getText().trim();
            String tel = telefono.getText().trim();
            String dir = direccion.getText().trim();

            if (n.isEmpty()) { showError("El nombre es requerido."); return; }

            if (c == null) {
                Cliente nc = new Cliente(n, co, tel, dir);
                if (clienteDAO.insertar(nc)) {
                    showInfo("Cliente creado. ID: " + nc.getId());
                    loadClientes();
                } else showError("Error al crear cliente.");
            } else {
                c.setNombre(n); c.setCorreo(co); c.setTelefono(tel); c.setDireccion(dir);
                if (clienteDAO.actualizar(c)) {
                    showInfo("Cliente actualizado.");
                    loadClientes();
                } else showError("Error al actualizar cliente.");
            }
        }
    }

    private void loadProductos() {
        productoModel.setRowCount(0);
        List<Producto> lista = productoDAO.listar();
        for (Producto p : lista) {
            productoModel.addRow(new Object[] { p.getId(), p.getNombre(), p.getDescripcion(), p.getPrecio(), p.getStock() });
        }
    }

    private void loadClientes() {
        clienteModel.setRowCount(0);
        List<Cliente> lista = clienteDAO.listar();
        for (Cliente c : lista) {
            clienteModel.addRow(new Object[] { c.getId(), c.getNombre(), c.getCorreo(), c.getTelefono(), c.getDireccion() });
        }
    }

    private void showInfo(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Info", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainWindow w = new MainWindow();
            w.setVisible(true);
        });
    }
}
