package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {
    private static final String URL = "jdbc:mysql://localhost:3306/inventario_db?useSSL=false&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = ""; // empty password - change if needed
    private static Connection conexion = null;

    public static Connection getConexion() throws SQLException {
        try {
            if (conexion == null || conexion.isClosed()) {
                Class.forName("com.mysql.cj.jdbc.Driver");
                conexion = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("[ConexionBD] Conexión exitosa a la base de datos");
            }
        } catch (ClassNotFoundException e) {
            System.err.println("[ConexionBD] Driver JDBC no encontrado: " + e.getMessage());
            throw new SQLException(e);
        }
        return conexion;
    }

    public static void closeConexion() {
        try {
            if (conexion != null && !conexion.isClosed()) {
                conexion.close();
                System.out.println("[ConexionBD] Conexión cerrada");
            }
        } catch (SQLException e) {
            System.err.println("[ConexionBD] Error al cerrar la conexión: " + e.getMessage());
        }
    }
}
