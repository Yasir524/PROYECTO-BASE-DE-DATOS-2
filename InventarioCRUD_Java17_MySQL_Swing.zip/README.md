# Sistema de Inventario CRUD (Avance 2) - Eclipse (Java 17) + MySQL

## Resumen
Proyecto en Java (Eclipse) usando Swing para la interfaz y MySQL (JDBC) para persistencia.
Contiene CRUD para Productos y Clientes.

## Requisitos
- Java 17
- MySQL 8+
- MySQL Connector/J (Añadir el JAR al Build Path en Eclipse)
- Eclipse IDE

## Configuración
1. Ejecutar `resources/inventario.sql` en tu servidor MySQL para crear la base de datos y tablas.
2. En `src/conexion/ConexionBD.java` verifica las credenciales. Actualmente está configurado como:
   - user = "root"
   - password = ""  (contraseña vacía)
   - url = "jdbc:mysql://localhost:3306/inventario_db?useSSL=false&serverTimezone=UTC"
3. Agrega MySQL Connector/J al proyecto (Project -> Properties -> Java Build Path -> Libraries -> Add External JARs).
4. Ejecutar la clase `vista.MainWindow` como Java Application para abrir la interfaz Swing.

## Estructura
- src/conexion/ConexionBD.java
- src/modelo/Producto.java
- src/modelo/Cliente.java
- src/dao/ProductoDAO.java
- src/dao/ClienteDAO.java
- src/vista/MainWindow.java
- resources/inventario.sql

## Entrega
- Subir todo el proyecto al repositorio de GitHub.
- Asegúrate de realizar commits claros que muestren contribución de cada integrante.
